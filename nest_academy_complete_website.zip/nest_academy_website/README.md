# Nest Academy website

A responsive six-page website for Shyma V.'s online mathematics tutoring academy.

## Files
- `index.html` — Home
- `about.html` — About Shyma V.
- `classes.html` — Classes and curriculum
- `booking.html` — Free trial request
- `register.html` — Academy registration enquiry
- `contact.html` — Contact and FAQs
- `style.css` — Shared responsive styles
- `script.js` — Mobile navigation, current year and date validation

## 1. Open in VS Code
1. Extract `nest_academy_website.zip`.
2. Open VS Code.
3. Choose **File → Open Folder** and select the extracted `nest_academy_website` folder.
4. Open `index.html`.
5. For the easiest preview, install the VS Code extension **Live Server**, right-click `index.html`, and select **Open with Live Server**. You can also open `index.html` directly in a browser.

## 2. Connect the forms to an email inbox
The three forms (`booking.html`, `register.html`, `contact.html`) currently use this placeholder:
`https://formsubmit.co/shymasuraj@gmail.com`

For each of those three files:
1. The forms are configured to send enquiries to `shymasuraj@gmail.com`.
2. On first use, complete the FormSubmit activation email sent to that inbox.
3. Save all three files.
4. Publish the website or test using the hosted version.
5. Submit a test form using your own details.
6. FormSubmit may send a one-time activation email to that address. Open it and confirm activation before expecting enquiries to arrive.
7. Check spam/junk as well as the inbox.

The forms use FormSubmit’s default response page after submission; no placeholder redirect is configured.

FormSubmit is a third-party service; review its current terms and privacy information before using it for real student information. Do not collect sensitive data. For children, a parent/guardian should submit the form.

## 3. Personalise before launch
- Replace the SV placeholder blocks with a real, approved photo of Shyma.
- Add the academy's actual email and WhatsApp number to `contact.html`.
- Confirm which grades, topics, class durations and formats are available.
- Add actual fees only after deciding the fee structure.
- Add real testimonials only with permission; do not publish invented reviews.
- Review privacy, cancellation, and child-safety information for your location and audience.

## 4. Publish for free using GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `nest-academy` (or another name).
3. Upload all files and folders from this project to the repository's root (not the ZIP itself).
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, select **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. Wait for GitHub Pages to publish the site. The address is usually `https://YOUR-USERNAME.github.io/nest-academy/`.
8. Test all six pages and all links on both phone and desktop.
9. Submit each form and confirm email delivery.

GitHub Pages hosts the static website, but it does not process form submissions itself. The forms above use FormSubmit as the external email handler.

## Notes
- Google Fonts need an internet connection; the site has fallback fonts.
- This starter does not take payments, confirm live appointment availability, or store student accounts in a database.
- If you later want a student portal, automatic calendar availability, payments, or a searchable student database, add a proper backend and privacy/security controls.


Tutor photo: `shyma-v.jpg` is used on the Home and About pages. Keep this image in the same folder as the HTML files when uploading the website.


Contact details currently displayed: shymasuraj@gmail.com and 9846184703. The phone number has been updated to 9846184703.
